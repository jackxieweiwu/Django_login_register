CREATE VIEW `schema_auto_increment_columns` AS
  SELECT
    `information_schema`.`COLUMNS`.`TABLE_SCHEMA`                                                             AS `table_schema`,
    `information_schema`.`COLUMNS`.`TABLE_NAME`                                                               AS `table_name`,
    `information_schema`.`COLUMNS`.`COLUMN_NAME`                                                              AS `column_name`,
    `information_schema`.`COLUMNS`.`DATA_TYPE`                                                                AS `data_type`,
    `information_schema`.`COLUMNS`.`COLUMN_TYPE`                                                              AS `column_type`,
    (locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) =
     0)                                                                                                       AS `is_signed`,
    (locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) >
     0)                                                                                                       AS `is_unsigned`,
    ((CASE `information_schema`.`COLUMNS`.`DATA_TYPE`
      WHEN 'tinyint'
        THEN 255
      WHEN 'smallint'
        THEN 65535
      WHEN 'mediumint'
        THEN 16777215
      WHEN 'int'
        THEN 4294967295
      WHEN 'bigint'
        THEN 18446744073709551615 END) >> if((locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) > 0), 0,
                                             1))                                                              AS `max_value`,
    `information_schema`.`TABLES`.`AUTO_INCREMENT`                                                            AS `auto_increment`,
    (`information_schema`.`TABLES`.`AUTO_INCREMENT` / ((CASE `information_schema`.`COLUMNS`.`DATA_TYPE`
                                                        WHEN 'tinyint'
                                                          THEN 255
                                                        WHEN 'smallint'
                                                          THEN 65535
                                                        WHEN 'mediumint'
                                                          THEN 16777215
                                                        WHEN 'int'
                                                          THEN 4294967295
                                                        WHEN 'bigint'
                                                          THEN 18446744073709551615 END) >> if((locate('unsigned',
                                                                                                       `information_schema`.`COLUMNS`.`COLUMN_TYPE`)
                                                                                                > 0), 0,
                                                                                               1)))           AS `auto_increment_ratio`
  FROM (`INFORMATION_SCHEMA`.`COLUMNS`
    JOIN `INFORMATION_SCHEMA`.`TABLES`
      ON (((`information_schema`.`COLUMNS`.`TABLE_SCHEMA` = `information_schema`.`TABLES`.`TABLE_SCHEMA`) AND
           (`information_schema`.`COLUMNS`.`TABLE_NAME` = `information_schema`.`TABLES`.`TABLE_NAME`))))
  WHERE (
    (`information_schema`.`COLUMNS`.`TABLE_SCHEMA` NOT IN ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema'))
    AND (`information_schema`.`TABLES`.`TABLE_TYPE` = 'BASE TABLE') AND
    (`information_schema`.`COLUMNS`.`EXTRA` = 'auto_increment'))
  ORDER BY (`information_schema`.`TABLES`.`AUTO_INCREMENT` / ((CASE `information_schema`.`COLUMNS`.`DATA_TYPE`
                                                               WHEN 'tinyint'
                                                                 THEN 255
                                                               WHEN 'smallint'
                                                                 THEN 65535
                                                               WHEN 'mediumint'
                                                                 THEN 16777215
                                                               WHEN 'int'
                                                                 THEN 4294967295
                                                               WHEN 'bigint'
                                                                 THEN 18446744073709551615 END) >> if((locate(
                                                                                                           'unsigned',
                                                                                                           `information_schema`.`COLUMNS`.`COLUMN_TYPE`)
                                                                                                       > 0), 0,
                                                                                                      1))) DESC,
    ((CASE `information_schema`.`COLUMNS`.`DATA_TYPE`
      WHEN 'tinyint'
        THEN 255
      WHEN 'smallint'
        THEN 65535
      WHEN 'mediumint'
        THEN 16777215
      WHEN 'int'
        THEN 4294967295
      WHEN 'bigint'
        THEN 18446744073709551615 END) >>
     if((locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) > 0), 0, 1))