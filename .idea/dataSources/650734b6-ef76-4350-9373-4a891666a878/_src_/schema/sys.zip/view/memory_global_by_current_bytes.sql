CREATE VIEW `memory_global_by_current_bytes` AS
  SELECT
    `performance_schema`.`memory_summary_global_by_event_name`.`EVENT_NAME`                                         AS `event_name`,
    `performance_schema`.`memory_summary_global_by_event_name`.`CURRENT_COUNT_USED`                                 AS `current_count`,
    `sys`.`format_bytes`(
        `performance_schema`.`memory_summary_global_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`)                  AS `current_alloc`,
    `sys`.`format_bytes`(ifnull(
                             (`performance_schema`.`memory_summary_global_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`
                              / nullif(`performance_schema`.`memory_summary_global_by_event_name`.`CURRENT_COUNT_USED`,
                                       0)),
                             0))                                                                                    AS `current_avg_alloc`,
    `performance_schema`.`memory_summary_global_by_event_name`.`HIGH_COUNT_USED`                                    AS `high_count`,
    `sys`.`format_bytes`(
        `performance_schema`.`memory_summary_global_by_event_name`.`HIGH_NUMBER_OF_BYTES_USED`)                     AS `high_alloc`,
    `sys`.`format_bytes`(ifnull(
                             (`performance_schema`.`memory_summary_global_by_event_name`.`HIGH_NUMBER_OF_BYTES_USED` /
                              nullif(`performance_schema`.`memory_summary_global_by_event_name`.`HIGH_COUNT_USED`, 0)),
                             0))                                                                                    AS `high_avg_alloc`
  FROM `performance_schema`.`memory_summary_global_by_event_name`
  WHERE (`performance_schema`.`memory_summary_global_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED` > 0)
  ORDER BY `performance_schema`.`memory_summary_global_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED` DESC